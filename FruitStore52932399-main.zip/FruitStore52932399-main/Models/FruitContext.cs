using FruitStore.Models;
using Microsoft.EntityFrameworkCore;

public class FruitContext(DbContextOptions<FruitContext> options) : DbContext(options)
{
    public virtual DbSet<Fruit> Fruits { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Fruit>()
            .HasData(
                new Fruit
                {
                    Id = 1,
                    Name = "Apple",
                    Description = "A delicious fruit. It's good for you!",
                    Instock = true,
                    Price = 0.99,
                    Origin = "Belgium"
                },
                new Fruit
                {
                    Id = 2,
                    Name = "Banana",
                    Description = "A yellow fruit. It's good for you!",
                    Instock = false,
                    Price = 0.99,
                    Origin = "Africa"
                },
                new Fruit
                {
                    Id = 3,
                    Name = "Orange",
                    Description = "A round fruit. It's good for you!",
                    Instock = true,
                    Price = 0.99,
                    Origin = "Spain"
                }
            );
    }
}