#!/bin/bash

echo "Hello World(wide learning)!"